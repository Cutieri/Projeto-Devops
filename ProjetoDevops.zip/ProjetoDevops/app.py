from flask import Flask, render_template, request, redirect, url_for, jsonify
import sqlite3

app = Flask(__name__)

def connect_to_database():
    # Conectar ao banco de dados `inventario.db`
    conn = sqlite3.connect('inventario.db')
    return conn

def add_server(nome, endereco_ip, sistema_operacional=None, especificacoes_hardware=None):
    # Conectar ao banco de dados
    conn = connect_to_database()
    cursor = conn.cursor()
    
    # Inserir o servidor na tabela `servidores`
    cursor.execute(
        "INSERT INTO servidores (nome, endereco_ip, sistema_operacional, especificacoes_hardware) "
        "VALUES (?, ?, ?, ?)",
        (nome, endereco_ip, sistema_operacional, especificacoes_hardware)
    )
    
    # Comitar as mudanças
    conn.commit()
    
    # Fechar a conexão com o banco de dados
    conn.close()


def list_servers():
    # Usar a tabela `servidores` em vez de `servers`
    conn = connect_to_database()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM servidores")
    servers = cursor.fetchall()
    conn.close()
    return servers

def update_server(server_id, nome, ip_address, operating_system=None):
    # Usar a tabela `servidores` em vez de `servers`
    conn = connect_to_database()
    cursor = conn.cursor()
    cursor.execute(
        "UPDATE servidores SET nome = ?, ip_address = ?, operating_system = ? WHERE id = ?",
        (nome, ip_address, operating_system, server_id)
    )
    conn.commit()
    conn.close()

def remove_server(server_id):
    # Usar a tabela `servidores` em vez de `servers`
    conn = connect_to_database()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM servidores WHERE id = ?", (server_id,))
    conn.commit()
    conn.close()

@app.route('/')
def index():
    servers = list_servers()
    return render_template('index.html', servers=servers)
        
@app.route('/add_server', methods=['POST'])
def add_server_route():
    # Obter dados do formulário
    nome = request.form.get('nome')
    endereco_ip = request.form.get('endereco_ip')
    sistema_operacional = request.form.get('sistema_operacional', None)
    especificacoes_hardware = request.form.get('especificacoes_hardware', None)
    
    # Chamar a função add_server com os argumentos apropriados
    add_server(nome, endereco_ip, sistema_operacional, especificacoes_hardware)
    
    # Redirecionar para a página inicial
    return redirect(url_for('index'))



if __name__ == '__main__':
    app.run(debug=True)
