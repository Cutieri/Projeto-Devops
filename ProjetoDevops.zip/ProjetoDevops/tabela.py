import mysql.connector

def connect_to_database():
    conn = mysql.connector.connect(
        host="localhost",
        port="3306",
        user="root",
        password="Fluuxy081105@",
        database="devopsdb"
    )
    return conn

def add_server(name, ip_address, operating_system=None):
    conn = connect_to_database()
    cursor = conn.cursor()
    cursor.execute("INSERT INTO servers (name, ip_address, operating_system) VALUES (%s, %s, %s)", (name, ip_address, operating_system))
    conn.commit()
    conn.close()

def list_servers():
    conn = connect_to_database()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM servers")
    servers = cursor.fetchall()
    conn.close()
    return servers


def update_server(server_id, name, ip_address, operating_system=None):
    conn = connect_to_database()
    cursor = conn.cursor()
    cursor.execute("UPDATE servers SET name=%s, ip_address=%s, operating_system=%s WHERE id=%s", (name, ip_address, operating_system, server_id))
    conn.commit()
    conn.close()

def remove_server(server_id):
    conn = connect_to_database()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM servers WHERE id=%s", (server_id,))
    conn.commit()
    conn.close()
