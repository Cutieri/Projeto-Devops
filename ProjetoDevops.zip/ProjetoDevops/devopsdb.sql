CREATE DATABASE devopsdb;

USE devopsdb;

CREATE TABLE IF NOT EXISTS servers (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name TEXT NOT NULL,
    ip_address TEXT NOT NULL,
    operating_system TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

select * FROM servers